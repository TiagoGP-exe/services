package ifmt.cba.servico;

import ifmt.cba.calc.Calculadora;
import jakarta.ws.rs.GET;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.PathParam;
import jakarta.ws.rs.Produces;
import jakarta.ws.rs.core.MediaType;

@Path("/calculadora1")
public class ServicoCalculadora1 {
    Calculadora calculadora = new Calculadora();

    @GET
    @Path("somar/{valor1}/{valor2}")
    @Produces(MediaType.TEXT_PLAIN)
    public double somar(@PathParam("valor1") double valor1, @PathParam("valor2") double valor2) {
        return calculadora.somar(valor1, valor2);
    }

    @GET
    @Path("subtrair/{valor1}/{valor2}")
    @Produces(MediaType.TEXT_PLAIN)
    public double subtrair(@PathParam("valor1") double valor1, @PathParam("valor2") double valor2) {
        return calculadora.subtrair(valor1, valor2);
    }

    @GET
    @Path("multiplicar/{valor1}/{valor2}")
    @Produces(MediaType.TEXT_PLAIN)
    public double multiplicar(@PathParam("valor1") double valor1, @PathParam("valor2") double valor2) {
        return calculadora.multiplicar(valor1, valor2);
    }

    @GET
    @Path("dividir/{valor1}/{valor2}")
    @Produces(MediaType.TEXT_PLAIN)
    public double dividir(@PathParam("valor1") double valor1, @PathParam("valor2") double valor2) {
        return calculadora.dividir(valor1, valor2);
    }
}