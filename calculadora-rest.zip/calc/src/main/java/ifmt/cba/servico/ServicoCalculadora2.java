package ifmt.cba.servico;

import ifmt.cba.calc.Calculadora;
import jakarta.ws.rs.GET;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.Produces;
import jakarta.ws.rs.QueryParam;
import jakarta.ws.rs.core.MediaType;

@Path("/calculadora2")
public class ServicoCalculadora2 {
    Calculadora calculadora = new Calculadora();

    @GET
    @Path("somar")
    @Produces(MediaType.TEXT_PLAIN)
    public double somar(@QueryParam("valor1") double valor1, @QueryParam("valor2") double valor2) {
        return calculadora.somar(valor1, valor2);
    }

    @GET
    @Path("subtrair")
    @Produces(MediaType.TEXT_PLAIN)
    public double subtrair(@QueryParam("valor1") double valor1, @QueryParam("valor2") double valor2) {
        return calculadora.subtrair(valor1, valor2);
    }
    
    @GET
    @Path("multiplicar")
    @Produces(MediaType.TEXT_PLAIN)
    public double multiplicar(@QueryParam("valor1") double valor1, @QueryParam("valor2") double valor2) {
        return calculadora.multiplicar(valor1, valor2);
    }

    @GET
    @Path("dividir")
    @Produces(MediaType.TEXT_PLAIN)
    public double dividir(@QueryParam("valor1") double valor1, @QueryParam("valor2") double valor2) {
        return calculadora.dividir(valor1, valor2);
    }
}