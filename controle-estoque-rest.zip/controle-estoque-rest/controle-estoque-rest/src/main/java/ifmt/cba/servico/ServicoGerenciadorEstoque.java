package ifmt.cba.servico;

import ifmt.cba.negocio.GerenciadorEstoque;
import ifmt.cba.vo.ProdutoVo;
import jakarta.ws.rs.Consumes;
import jakarta.ws.rs.GET;
import jakarta.ws.rs.POST;
import jakarta.ws.rs.PUT;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.PathParam;
import jakarta.ws.rs.Produces;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.Response;
import jakarta.ws.rs.core.Response.ResponseBuilder;

@Path("/produtos")
public class ServicoGerenciadorEstoque {

    private static GerenciadorEstoque gerenciadorEstoque;

    static {
        gerenciadorEstoque = new GerenciadorEstoque();
    }

    @POST
    @Consumes(MediaType.APPLICATION_JSON)
    @Produces(MediaType.APPLICATION_JSON)
    public Response adicionarProduto(ProdutoVo produtoVo) {
        String retorno;

        try {
            gerenciadorEstoque.adicionarEstoque(produtoVo);
            retorno = "Produto adicionado com sucesso!";
        } catch (Exception ex) {
            retorno = ex.getMessage();
        }
        ResponseBuilder reposta = Response.ok();
        reposta.entity(retorno);
        return reposta.build();
    }

    @PUT
    @Consumes(MediaType.APPLICATION_JSON)
    @Produces(MediaType.APPLICATION_JSON)
    public Response removerProduto(ProdutoVo produtoVo) {
        String retorno;

        try {
            gerenciadorEstoque.removerProduto(produtoVo);
            retorno = "Produto atualizado com sucesso!";
        } catch (Exception ex) {
            retorno = ex.getMessage();
        }
        ResponseBuilder reposta = Response.ok();
        reposta.entity(retorno);
        return reposta.build();
    }

    @PUT
    @Path("/adicionar/{qtde}")
    @Consumes(MediaType.APPLICATION_JSON)
    public void adicionarEstoqueProduto(@PathParam("qtde") int quantidade, ProdutoVo produtoVo) throws Exception {
        gerenciadorEstoque.adicionarEstoqueProduto(produtoVo, quantidade);
    }

    @PUT
    @Path("/baixar/{qtde}")
    @Consumes(MediaType.APPLICATION_JSON)
    public void baixarEstoqueProduto(@PathParam("qtde") int quantidade, ProdutoVo produtoVo) throws Exception {
        gerenciadorEstoque.baixarEstoqueProduto(produtoVo, quantidade);
    }

    @GET
    @Path("/contar")
    @Produces(MediaType.APPLICATION_JSON)
    public Response contadorProduto(ProdutoVo produtoVo) {
        int total = gerenciadorEstoque.contadorProduto();

        ResponseBuilder resposta = Response.ok();
        resposta.entity(total);
        return resposta.build();
    }

    
    @GET
    @Path("/buscar/{codigo}")
    @Produces(MediaType.APPLICATION_JSON)
    public Response buscarProdutoPorCodigo(@PathParam("codigo") int codigo) {
        ProdutoVo retorno = gerenciadorEstoque.buscarProdutoPorCodigo(codigo);

        ResponseBuilder resposta = Response.ok();
        resposta.entity(retorno);
        return resposta.build();
    }

    @GET
    @Produces(MediaType.APPLICATION_JSON)
    public Response listaProduto() {
        ResponseBuilder resposta = Response.ok();

        resposta.entity(gerenciadorEstoque.listaProduto());
        return resposta.build();
    }

    @GET
    @Path("/estoque")
    @Produces(MediaType.APPLICATION_JSON)
    public Response totalEstoqueFisico() {
        ResponseBuilder resposta = Response.ok();

        resposta.entity(gerenciadorEstoque.totalEstoqueFisico());
        return resposta.build();
    }
    
}
