package ifmt.cba.negocio;

import java.util.ArrayList;

import ifmt.cba.vo.ProdutoVo;

public class GerenciadorEstoque {
    private ArrayList<ProdutoVo> listaProduto;

    public GerenciadorEstoque() {
        this.listaProduto = new ArrayList<ProdutoVo>();
    }

    public void adicionarEstoque(ProdutoVo produtoVo) throws Exception {
        if(produtoVo != null ) {
            if(this.buscarProdutoPorCodigo(produtoVo.getCodigo()) == null) {
                this.listaProduto.add(produtoVo);
            } else {
                throw new Exception("Produto ja existe");
            }
        } else {
            throw new Exception("Produto não pode ser nulo");
        }
    }

    public void removerProduto(ProdutoVo produtoVo) throws Exception {
        if (produtoVo != null) {
            if (this.listaProduto.indexOf(produtoVo) >= 0) {
                this.listaProduto.remove(produtoVo);
            } else {
                throw new Exception("Produto não localizado");
            }
        } else {
            throw new Exception("Produto não pode ser nulo"); 
        }
    }

    public void adicionarEstoqueProduto(ProdutoVo produtoVo, int quantidade) throws Exception {
        if (produtoVo != null || quantidade > 0) {
            if (this.listaProduto.indexOf(produtoVo) >= 0) {
                ProdutoVo produtoVoTemp = this.listaProduto.get(this.listaProduto.indexOf(produtoVo));
                produtoVoTemp.adicionarEstoque(quantidade);
            } else {
                throw new Exception("Produto não localizado");
            }
        } else {
            throw new Exception("Produto ou quantidade incosistente");
        }
    }


    public void baixarEstoqueProduto(ProdutoVo produtoVo, int quantidade) throws Exception {
        if (produtoVo != null || quantidade > 0) {
            if (this.listaProduto.indexOf(produtoVo) >= 0) {
                ProdutoVo produtoVoTemp = this.listaProduto.get(this.listaProduto.indexOf(produtoVo));
                produtoVoTemp.baixarEstoque(quantidade);
            } else {
                throw new Exception("Produto não localizado");
            }
        } else {
            throw new Exception("Produto ou quantidade incosistente");
        }
    }

    public ProdutoVo buscarProdutoPorCodigo(int codigo) {
        ProdutoVo produtoVoTemp = null;

        for (ProdutoVo produtoVo : this.listaProduto) {
            if (produtoVo.getCodigo() == codigo) {
                produtoVoTemp = produtoVo;
                break;
            }
        }

        return produtoVoTemp;
    }

    public int contadorProduto() {
        return this.listaProduto.size();
    }

    public ArrayList<ProdutoVo> listaProduto() {
        return this.listaProduto;
    }

    public int totalEstoqueFisico() {
        int total = 0;
        for (ProdutoVo produtoVo : this.listaProduto) {
            total += produtoVo.getEstoque();
        }
        return total;
    }
}
