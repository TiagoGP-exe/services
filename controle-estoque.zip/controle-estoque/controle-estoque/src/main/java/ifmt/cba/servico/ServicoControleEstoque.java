package ifmt.cba.servico;

import java.util.ArrayList;

import ifmt.cba.vo.ProdutoVo;
import jakarta.jws.WebMethod;
import jakarta.jws.WebService;
import jakarta.jws.soap.SOAPBinding;
import jakarta.jws.soap.SOAPBinding.Style;

// Service Endpoint Interface (SEI)

@WebService
@SOAPBinding(style = Style.DOCUMENT)
public interface ServicoControleEstoque {

    @WebMethod()
    public void adicionarProduto(ProdutoVo produtoVo) throws Exception;

    @WebMethod()
    public void removeProduto(ProdutoVo produtoVo) throws Exception;

    @WebMethod()
    public void adicionarEstoqueProduto(ProdutoVo produtoVo, int quantidade) throws Exception; 

    @WebMethod() 
    public void baixarEstoqueProduto(ProdutoVo produtoVo, int quantidade) throws Exception; 

    @WebMethod()
    public int contadorProduto();

    @WebMethod()
    public ProdutoVo buscarProdutoPorCodigo(int codigo);

    @WebMethod()
    public ArrayList<ProdutoVo> listaProduto();

    @WebMethod()
    public int totalEstoqueFisico();
}
