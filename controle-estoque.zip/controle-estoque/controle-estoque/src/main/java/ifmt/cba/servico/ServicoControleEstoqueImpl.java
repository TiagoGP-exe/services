package ifmt.cba.servico;

import java.util.ArrayList;

import ifmt.cba.negocio.GerenciadorEstoque;
import ifmt.cba.vo.ProdutoVo;
import jakarta.jws.WebService;

@WebService(endpointInterface = "ifmt.cba.servico.ServiceControleEstoque")
public class ServicoControleEstoqueImpl implements ServicoControleEstoque {
    private GerenciadorEstoque gerenciadorEstoque;

    public ServicoControleEstoqueImpl() {
        this.gerenciadorEstoque = new GerenciadorEstoque();
    }

    @Override
    public void adicionarProduto(ProdutoVo produtoVo) throws Exception {
        this.gerenciadorEstoque.adicionarEstoque(produtoVo);
    }

    @Override
    public void removeProduto(ProdutoVo produtoVo) throws Exception {
        this.gerenciadorEstoque.removerProduto(produtoVo);
    }

    @Override
    public void adicionarEstoqueProduto(ProdutoVo produtoVo, int quantidade) throws Exception {
        this.gerenciadorEstoque.baixarEstoqueProduto(produtoVo, quantidade);
    }

    @Override
    public void baixarEstoqueProduto(ProdutoVo produtoVo, int quantidade) throws Exception {
        this.gerenciadorEstoque.baixarEstoqueProduto(produtoVo, quantidade);
    }

    @Override
    public int contadorProduto() {
        return this.gerenciadorEstoque.contadorProduto();
    }

    @Override
    public ProdutoVo buscarProdutoPorCodigo(int codigo) {
        return this.gerenciadorEstoque.buscarProdutoPorCodigo(codigo);
    }

    @Override
    public ArrayList<ProdutoVo> listaProduto() {
        return this.gerenciadorEstoque.listaProduto();
    }

    @Override
    public int totalEstoqueFisico() {
        return this.gerenciadorEstoque.totalEstoqueFisico();
    }
}
