package ifmt.cba.servico;

import jakarta.ws.rs.DefaultValue;
import jakarta.ws.rs.GET;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.PathParam;
import jakarta.ws.rs.Produces;
import jakarta.ws.rs.QueryParam;
import jakarta.ws.rs.core.MediaType;

@Path("/calcular")
public class WSJuros {

    @GET
    @Path("jurossimples1/{cap}/{tax}/{per}")
    @Produces(MediaType.TEXT_PLAIN)
    public float jurosSimples1(@PathParam("cap") float capital, @PathParam("tax") float taxa,
            @PathParam("per") float periodo) {
        return capital * (taxa / 100) * periodo;
    }

    @GET
    @Path("jurossimples2")
    @Produces(MediaType.TEXT_PLAIN)
    public float jurosSimples2 (@QueryParam("cap") float capital, @QueryParam("tax") float taxa, @QueryParam("per") float periodo) {
        return capital * (taxa /100) * periodo; 
    }

    @GET
    @Path("jurossimples3")
    @Produces(MediaType.TEXT_PLAIN)
    public float jurosSimples3 (@DefaultValue("0.0") @QueryParam("cap") float capital,@DefaultValue("1.0") @QueryParam("tax") float taxa,@DefaultValue("1.0") @QueryParam("per") float periodo) {
        return capital * (taxa /100) * periodo; 
    }

}
